import Dashboard from './Dashboard';
declare const _default: {
    Dashboard: typeof Dashboard;
};
export default _default;
