import React from 'react';
import { type DeviceType } from '../../shared/device-registry';
import { ConfigGeneric, type ConfigGenericProps, type ConfigGenericState } from '@iobroker/json-config';
type Bridge = {
    id: string;
    name: string;
    port: number | string;
};
type Device = {
    id: string;
    bridgeId: string;
    name: string;
    type: DeviceType;
    stateId: string;
    brightnessStateId?: string;
    [key: string]: string | undefined;
};
interface BridgeRuntime {
    status: string;
    pairingQr: string;
    pairingManualCode: string;
    commissioned: boolean;
    fabricCount: number;
}
interface DashboardState extends ConfigGenericState {
    bridgeDraft: Bridge;
    deviceDraft: Device;
    showSelectId: boolean;
    selectIdTarget: 'stateId' | 'brightnessStateId';
    bridgeRuntime: Record<string, BridgeRuntime>;
}
export default class Dashboard extends ConfigGeneric<ConfigGenericProps, DashboardState> {
    private bridgeSubscriptions;
    componentDidMount(): Promise<void>;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    private syncBridgeSubscriptions;
    constructor(props: ConfigGenericProps);
    private readArray;
    private updateBridges;
    private updateDevices;
    private updateBridgeDraft;
    private updateDeviceDraft;
    private refreshBridgeRuntime;
    private deleteBridge;
    private reopenBridgeCommissioning;
    private openSelectId;
    private getSelectedDeviceDefinition;
    private getAdditionalStateFields;
    private renderSelectIdDialog;
    private addBridge;
    private addDevice;
    renderItem(_error: string, _disabled: boolean, _defaultValue?: unknown): React.JSX.Element;
}
export {};
